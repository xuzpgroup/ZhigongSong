importfile('tube15-15.xyz');data15=data;data15(:,1)=data15(:,1)+18.41;data15(:,2)=data15(:,2)+13.5273;data15(:,3)=data15(:,3)+60;
importfile('tube16-16.xyz');data16=data;data16(:,1)=data16(:,1)+18.41;data16(:,2)=data16(:,2)+13.5273;data16(:,3)=data16(:,3)+60;
importfile('tube17-17.xyz');data17=data;data17(:,1)=data17(:,1)+18.41;data17(:,2)=data17(:,2)+13.5273;data17(:,3)=data17(:,3)+60;
importfile('tube18-18.xyz');data18=data;data18(:,1)=data18(:,1)+18.41;data18(:,2)=data18(:,2)+13.5273;data18(:,3)=data18(:,3)+60;
importfile('tube19-19.xyz');data19=data;data19(:,1)=data19(:,1)+18.41;data19(:,2)=data19(:,2)+13.5273;data19(:,3)=data19(:,3)+60;
importfile('tube20-20.xyz');data20=data;data20(:,1)=data20(:,1)+18.41;data20(:,2)=data20(:,2)+13.5273;data20(:,3)=data20(:,3)+60;